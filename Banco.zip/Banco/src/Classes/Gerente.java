/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.util.ArrayList;

/**
 *
 * @author aluno
 */
public class Gerente {
    private int codigoGerente;
    private long cpfGerente;
    private String nomeGerente;
    private String funcao;
    
    private ArrayList<Cliente> clientes;

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }
    
    
    public Gerente(){
        this.clientes = new ArrayList();
    }
    
    public void inserirCliente(Cliente cli){
        this.clientes.add(cli);
    }
    
}